import requests
import json
from config import KIWI_URL, USERNAME, PASSWORD



class KiwiTCMSAPI:
    def __init__(self, kiwi_url=KIWI_URL, username=USERNAME, password=PASSWORD):
        self.kiwi_url = kiwi_url
        self.username = username
        self.password = password
        self.session_token = None

    def authenticate(self):
        headers = {'Content-Type': 'application/json'}
        payload = {
            "method": "Auth.login",
            "params": [self.username, self.password],
            "jsonrpc": "2.0",
            "id": 1
        }

        response = requests.post(self.kiwi_url, data=json.dumps(payload), headers=headers)
        return response.json()

    def check_connection(self):
        response_data = self.authenticate()

        if response_data.get('result'):
            print("Connection successful!")
            self.session_token = response_data['result']
            print(self.session_token)
            return True
        else:
            print("Connection failed!")
            return False

    def create_test_run(self, summary, plan_id, build_id, manager_id):
        """Dynamically create a test run with the provided parameters."""
        if not self.session_token:
            print("Authentication required.")
            return None

        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.session_token}'  # Add session token in the header
        }

        # Construct the payload dynamically
        payload = {
            "jsonrpc": "2.0",
            "method": "TestRun.create",
            "params": {
                "values": {
                    "summary": summary,  # Name of the test run
                    "plan": plan_id,  # ID of the test plan
                    "build": build_id,  # Build associated with the test run
                    "manager": manager_id,  # Your user ID as the test manager

                }
            },
            "id": 1
        }

        response = requests.post(self.kiwi_url, data=json.dumps(payload), headers=headers)
        response_data = response.json()

        if response_data.get('result'):
            return response_data['result']
        else:
            print(f"Failed to create test run. Error details: {response_data}")
            return None
