# config.py
KIWI_URL = "https://kiwitcms.cognitivzen.com//json-rpc/"
USERNAME = "anusha.ampili@congnitivzen.com"
PASSWORD = "IloveNani@123"
