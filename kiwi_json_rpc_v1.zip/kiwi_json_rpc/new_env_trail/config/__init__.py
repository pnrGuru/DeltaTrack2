import os
from dotenv import load_dotenv

# Load environment variables from the .env file
load_dotenv()

KIWI_URL = os.getenv("KIWI_URL")
USERNAME = os.getenv("USERNAME")
PASSWORD = os.getenv("PASSWORD")

if not all([KIWI_URL, USERNAME, PASSWORD]):
    raise ValueError("KIWI_URL, USERNAME, or PASSWORD is missing from the environment variables.")
