import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

KIWI_URL = os.getenv("KIWI_URL")
USERNAME = os.getenv("USERNAME")
PASSWORD = os.getenv("PASSWORD")

if not all([KIWI_URL, USERNAME, PASSWORD]):
    raise ValueError("Kiwi TCMS credentials are missing!")

