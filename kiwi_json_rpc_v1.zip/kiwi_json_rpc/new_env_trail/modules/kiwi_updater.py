from config import KIWI_URL

class KiwiTestUpdater:
    def __init__(self, connection):
        self.connection = connection

    def update_test_execution(self, test_case_id, run_id, status, notes):
        # Fetch the execution details using the test case ID and run ID
        payload_get_execution = {
            "jsonrpc": "2.0",
            "method": "TestExecution.filter",
            "params": {
                "query": {
                    "run": run_id,
                    "case": test_case_id,
                }
            },
            "id": 1,
        }
        response = self.connection.session.post(KIWI_URL, json=payload_get_execution)
        execution = response.json()
        if "error" in execution:
            raise Exception(f"Error retrieving execution: {execution['error']}")

        if not execution["result"]:
            raise Exception(f"No execution found for Test Case ID {test_case_id}.")

        execution_id = execution["result"][0]["id"]

        # Update the execution status
        payload_update_execution = {
            "jsonrpc": "2.0",
            "method": "TestExecution.update",
            "params": {
                "execution_id": execution_id,
                "values": {
                    "status": status,  # 4 = Passed, 5 = Failed
                    "notes": notes,
                },
            },
            "id": 1,
        }
        response = self.connection.session.post(KIWI_URL, json=payload_update_execution)
        result = response.json()
        if "error" in result:
            raise Exception(f"Error updating execution: {result['error']}")

        print(f"Test Case ID {test_case_id} updated successfully with status {status}.")
