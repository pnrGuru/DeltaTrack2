from datetime import datetime, timedelta

import requests
from config import KIWI_URL, USERNAME, PASSWORD
from tests.test_login import manager_id


class KiwiConnection:
    def __init__(self):
        self.session = requests.Session()

    def login(self):
        # Payload for login
        payload = {
            "jsonrpc": "2.0",
            "method": "Auth.login",
            "params": {
                "username": USERNAME,
                "password": PASSWORD,
            },
            "id": 1,
        }
        response = self.session.post(KIWI_URL, json=payload)
        result = response.json()

        # Check if login was successful
        if "error" in result:
            raise Exception(f"Login failed: {result['error']}")

        print("Login successful!")
        return True

    def check_connection(self):
        # Try logging in to confirm connection
        try:
            self.login()  # Attempt to log in
            return True  # If successful
        except Exception as e:
            print(f"Connection failed: {e}")
            return False

    def create_test_case(self):
        # Prepare the data for the test case creation
        payload_create_test_case = {
            "jsonrpc": "2.0",
            "method": "TestCase.create",
            "params": {
                "values": {
                    "summary": "Verify login@A functionality",
                    "case_status": 2,  # Approved
                    "priority": 2,  # High Priority
                    "author": 1,  # User ID (assumed)
                    "product_id": 1,  # Product ID
                    "product_version": "v1.0",  # Product Version
                    "category": 1,  # Category ID
                    "component_id": 1,  # Component ID
                    "text": """Steps to reproduce:
                    1. Go to login page
                    2. Enter valid credentials
                    3. Click login button
                    Expected result: User should be logged in successfully.""",
                    "tags": ["login", "functional"]
                }
            },
            "id": 1
        }

        response = self.session.post(KIWI_URL, json=payload_create_test_case)
        result = response.json()

        if "error" in result:
            raise Exception(f"Error creating test case: {result['error']}")
        print(f"Test case created successfully: {result['result']}")

    def create_test_run(self, summary, product_id, version, category_id,plan_id,build_id,manager_id):

        """
        Create a new test run.

        :param manager_id:
        :param build_id:
        :param plan_id:
        :param summary: Summary of the test run.
        :param product_id: Product ID.
        :param version: Product version.
        :param category_id: Category ID.
        :return: ID of the created test run.
        """
        payload_create_test_run = {
            "jsonrpc": "2.0",
            "method": "TestRun.create",
            "params": {
                "values": {
                    "summary": summary,
                    "product_id": product_id,
                    "plan":plan_id,
                    "build":build_id,
                    "version": version,
                    "category_id": category_id,
                    "is_draft": True,  # Mark as draft
                    "manager":manager_id


                }
            },
            "id": 1
        }

        response = self.session.post(KIWI_URL, json=payload_create_test_run)
        result = response.json()

        if "error" in result:
            raise Exception(f"Error creating test run: {result['error']}")
        print(f"Test run created successfully: {result['result']}")
        return result['result']['id']  # Return test run ID

    def add_multiple_test_cases_to_run(self, run_id, case_ids):
        """
        Add multiple test cases to an existing test run.
        :param run_id: ID of the test run.
        :param case_ids: List of test case IDs to add.
        """
        for case_id in case_ids:
            try:
                payload_add_case = {
                    "jsonrpc": "2.0",
                    "method": "TestRun.add_case",
                    "params": {
                        "run_id": run_id,
                        "case_id": case_id
                    },
                    "id": 1
                }

                response = self.session.post(KIWI_URL, json=payload_add_case)
                result = response.json()

                if "error" in result:
                    raise Exception(f"Error adding test case {case_id} to test run {run_id}: {result['error']}")
                print(f"Test case {case_id} added to test run {run_id} successfully.")

            except Exception as e:
                print(f"Failed to add test case {case_id}: {str(e)}")

    def get_test_execution_id(self, run_id, case_id):
        """Fetch the execution ID for a test case in a specific test run."""
        payload = {
            "jsonrpc": "2.0",
            "method": "TestExecution.filter",
            "params": {
                "query": {
                    "run": run_id,
                    "case": case_id
                }
            },
            "id": 1
        }
        response = self.session.post(KIWI_URL, json=payload)
        result = response.json()
        if "error" in result:
            raise Exception(f"Error retrieving test execution: {result['error']}")
        if not result["result"]:
            raise Exception(f"No execution found for run_id={run_id} and case_id={case_id}")
        execution_id = result["result"][0]["id"]
        return execution_id

    def update_test_run_results(self, execution_id, status, notes,test_case_id):
        """Update the test result for a specific execution."""
        payload = {
            "jsonrpc": "2.0",
            "method": "TestExecution.update",
            "params": {
                "execution_id": execution_id,
                "values": {
                    "status": status,  # 2 for Passed, 3 for Failed
                    "notes": notes
                }
            },
            "id": 1
        }
        response = self.session.post(KIWI_URL, json=payload)
        result = response.json()
        if "error" in result:
            raise Exception(f"Error updating test result: {result['error']}")
        print(f"Test execution ID {execution_id} updated successfully with status {status}.")
        return result

