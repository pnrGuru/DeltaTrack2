import pytest
from kiwi_connection import KiwiConnection
from kiwi_updater import KiwiTestUpdater

class TestExecutor:
    def __init__(self):
        self.connection = KiwiConnection()
        self.connection.login()
        self.updater = KiwiTestUpdater(connection=self.connection)

    def run_test(self, test_case_id, run_id, test_func):
        try:
            # Execute the test function
            test_func()
            print(f"Test Case ID {test_case_id} passed.")
            # Update the test case as passed
            self.updater.update_test_execution(
                test_case_id=test_case_id,
                run_id=run_id,
                status=4,  # Passed
                notes="Test passed successfully.",
            )
        except AssertionError as e:
            print(f"Test Case ID {test_case_id} failed: {e}")
            # Update the test case as failed
            self.updater.update_test_execution(
                test_case_id=test_case_id,
                run_id=run_id,
                status=5,  # Failed
                notes=f"Test failed: {str(e)}",
            )
