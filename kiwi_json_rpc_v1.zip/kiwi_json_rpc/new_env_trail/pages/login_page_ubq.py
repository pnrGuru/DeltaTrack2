from playwright.sync_api import Page

class LoginPage:
    def __init__(self, page: Page):
        self.page = page
        self.username_field = '//input[@id="username"]'
        self.continue_btn = '//button[contains(text(),"Continue")]'
        self.password_field = '//input[@id="password"]'
        self.dashboard_text = '//h2[contains(text(),"Network Admin")]'

    def navigate_to_login(self, url: str):
        self.page.goto(url)
        # Wait for the page to load completely
        self.page.wait_for_load_state('networkidle')

    def enter_username(self, username: str):
        # Wait for the username field to be visible
        self.page.wait_for_selector(self.username_field)
        self.page.fill(self.username_field, username)

    def click_continue(self):
        # Wait for the continue button to be visible
        self.page.wait_for_selector(self.continue_btn)
        self.page.click(self.continue_btn)

    def enter_password(self, password: str):
        # Wait for the password field to be visible
        self.page.wait_for_selector(self.password_field)
        self.page.fill(self.password_field, password)

    def is_dashboard_visible(self):
        # Wait for the dashboard text to appear
        self.page.wait_for_selector(self.dashboard_text, timeout=10000)  # Timeout of 10 seconds
        return self.page.is_visible(self.dashboard_text)

