from datetime import datetime, timedelta

import pytest
from playwright.sync_api import sync_playwright
from new_env_trail.modules.kiwi_connection import KiwiConnection
from new_env_trail.pages.login_page_ubq import LoginPage

@pytest.mark.add_multiple_test_cases_to_run
def test_ubq_network_login_and_dashboard():
    # Create an instance of KiwiConnection
    kiwi_connection = KiwiConnection()

    # Check if connection to Kiwi TCMS is successful
    if kiwi_connection.check_connection():
        print("Connection to Kiwi TCMS was successful!")
        # Step 1: Create a test run
        test_run_id = kiwi_connection.create_test_run(
            summary="Test Run for Login and Dashboard Validation-@jsonapproach",
            product_id=2,
            plan_id=10,
            build_id=2,
            version="v1.0",  # Replace with your Product Version
            category_id=1,
            manager_id=1,

        )

        # Step 2: Add multiple test cases to the test run
        test_case_ids = [36, 37, 38]  # Replace with actual Test Case IDs from your system
        kiwi_connection.add_multiple_test_cases_to_run(run_id=test_run_id, case_ids=test_case_ids)

        # Initialize result list to track pass/fail for each test case
        test_case_results = []

        # Run 1: Launch Browser (Test Case 1)
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                page = browser.new_page()
                print("Browser launched successfully.")
                browser.close()  # Close the browser after launch

            # Record the result for Browser Launch Test Case
            test_case_results.append({"test_case_id": 36, "status": 4})  # 3 is the status for 'Pass'

        except Exception as e:
            test_case_results.append({"test_case_id": 36, "status": 5, "notes": str(e)})  # 4 is the status for 'Fail'

        # Run 2: Login to UBQ Network (Test Case 2)
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=False)
                page = browser.new_page()

                login_page = LoginPage(page)

                # Navigate to the login page
                login_page.navigate_to_login("https://qa.app.ubq.network/")
                login_page.enter_username("sgadamsetty+padmin@deltatrak.com")
                login_page.click_continue()
                login_page.enter_password("uM7p2H1n5c")
                login_page.click_continue()

                # Check if the dashboard is visible after login
                try:
                    assert login_page.is_dashboard_visible(), "Dashboard is not visible after login."
                    result = 4  # Status ID for 'Pass'
                except AssertionError:
                    result = 5  # Status ID for 'Fail'

                # Record the result for Login Test Case
                test_case_results.append({"test_case_id": 37, "status": result})

                browser.close()  # Close the browser after login

        except Exception as e:
            test_case_results.append({"test_case_id": 37, "status": 5, "notes": str(e)})  # 4 is the status for 'Fail'

        # Run 3: Validate Dashboard (Test Case 3)
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                page = browser.new_page()

                login_page = LoginPage(page)

                # Navigate to the login page and log in
                # Navigate to the login page
                login_page.navigate_to_login("https://qa.app.ubq.network/")
                login_page.enter_username("sgadamsetty+padmin@deltatrak.com")
                login_page.click_continue()
                login_page.enter_password("uM7p2H1n5c")
                login_page.click_continue()

                # Validate if dashboard is visible
                try:
                    assert login_page.is_dashboard_visible(), "Dashboard is not visible after login."
                    result = 1  # Status ID for 'Pass'
                except AssertionError:
                    result = 8  # Status ID for 'Fail'

                # Record the result for Dashboard Validation Test Case
                test_case_results.append({"test_case_id": 38, "status": result})

                browser.close()  # Close the browser after validation

        except Exception as e:
            test_case_results.append({"test_case_id": 38, "status": 8, "notes": str(e)})  # 4 is the status for 'Fail'

        # Step 3: Update results in Kiwi TCMS dynamically
        for result in test_case_results:
            # Get the execution ID for each test case
            execution_id = kiwi_connection.get_test_execution_id(test_run_id, result["test_case_id"])

            # Update the result for each test case in the test run
            kiwi_connection.update_test_run_results(
                execution_id=execution_id,  # Use the execution ID
                status=result["status"],
                notes=result.get("notes", "No additional notes."),
                test_case_id=result["test_case_id"]
            )

    else:
        print("Connection to Kiwi TCMS failed!")






