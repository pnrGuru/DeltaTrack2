import pytest
from new_env_trail.modules.kiwi_connection import KiwiConnection
from tests.test_login import environment


@pytest.mark.check_connection
def test_check_kiwi_connection():
    # Create an instance of KiwiConnection
    kiwi_connection = KiwiConnection()

    # Check if connection is successful
    connection_status = kiwi_connection.check_connection()

    # Assert that connection is successful
    assert connection_status is True, "Connection to Kiwi TCMS failed!"
@pytest.mark.create_test_case
def test_create_test_case():
    # Create an instance of KiwiConnection
    kiwi_connection = KiwiConnection()

    # Check if connection is successful
    if kiwi_connection.check_connection():
        print("Connection to Kiwi TCMS was successful!")

        # Create a new test case
        kiwi_connection.create_test_case()

    else:
        print("Connection to Kiwi TCMS failed!")

@pytest.mark.create_test_run
def test_create_test_run():
        kiwi_connection = KiwiConnection()

        # Check if connection is successful
        if kiwi_connection.check_connection():
            print("Connection to Kiwi TCMS was successful!")

            # Step 1: Create a test run
            test_run_id = kiwi_connection.create_test_run(
                summary="Test Run for Login Functionality@json",
                product_id=2,
                plan_id=10,
                build_id=2,
                version="v1.0",  # Replace with your Product Version
                category_id=1,
                manager_id=1,

            )

@pytest.mark.add_multiple_test_cases_to_run
def test_add_multiple_test_cases_to_run():
    # Create an instance of KiwiConnection
    kiwi_connection = KiwiConnection()

    # Check if connection is successful
    if kiwi_connection.check_connection():
        print("Connection to Kiwi TCMS was successful!")

        # Step 1: Create a test run
        test_run_id = kiwi_connection.create_test_run(
            summary="Test Run for Login Functionality@json2",
            product_id=2,
            plan_id=10,
            build_id=2,
            version="v1.0",  # Replace with your Product Version
            category_id=1,
            manager_id=1
         )

        # Step 2: Add multiple test cases to the test run
        test_case_ids = [36, 37, 38]  # Replace with your Test Case IDs
        kiwi_connection.add_multiple_test_cases_to_run(run_id=test_run_id, case_ids=test_case_ids)

    else:
        print("Connection to Kiwi TCMS failed!")
@pytest.mark.add_multiple_test_cases_to_run
def test_update_execution():
    # Create an instance of KiwiConnection
    kiwi_connection = KiwiConnection()

    # Check if connection is successful
    if kiwi_connection.check_connection():
        print("Connection to Kiwi TCMS was successful!")

        # Step 1: Create a test run
        test_run_id = kiwi_connection.create_test_run(
            summary="Test Run for Login Functionality@json2",
            product_id=2,
            plan_id=10,
            build_id=2,
            version="v1.0",  # Replace with your Product Version
            category_id=1,
            manager_id=1
         )

        # Step 2: Add multiple test cases to the test run
        test_case_ids = [36]  # Replace with your Test Case IDs
        kiwi_connection.add_multiple_test_cases_to_run(run_id=test_run_id, case_ids=test_case_ids)

    else:
        print("Connection to Kiwi TCMS failed!")