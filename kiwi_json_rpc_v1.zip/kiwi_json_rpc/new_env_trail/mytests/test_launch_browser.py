from playwright.sync_api import sync_playwright

def test_launch_browser():
    """Test case for launching the browser."""
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)  # Set headless=True if you want to hide the browser window
        page = browser.new_page()
        print("Browser launched successfully.")
        browser.close()  # Close the browser after launch
