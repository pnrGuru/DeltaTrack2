import os
import requests
import pytest
from typing import Dict

# Constants
KIWI_URL="https://kiwitcms.cognitivzen.com//json-rpc/"
USERNAME="anusha.ampili@congnitivzen.com"
PASSWORD="IloveNani@123"

STATUS_CODES = {
    "blocked": 1,
    "passed": 2,
    "failed": 3,
    "not_run": 4,
    "in_progress": 5,
    "paused": 6,
}  # Kiwi TCMS execution statuses

# Session for Kiwi TCMS API
session = requests.Session()


class KiwiTCMS:
    """Utility class to interact with Kiwi TCMS via JSON-RPC."""

    @staticmethod
    def test_login():
        """Logs into Kiwi TCMS and starts a session."""
        payload = {
            "jsonrpc": "2.0",
            "method": "Auth.login",
            "params": {"username": USERNAME, "password": PASSWORD},
            "id": 1,
        }
        response = session.post(KIWI_URL, json=payload)
        result = response.json()
        if "error" in result:
            raise Exception(f"Login failed: {result['error']}")
        print("Login successful!")

    @staticmethod
    def update_test_execution(test_case_id: int, run_id: int, status: str, notes: str):
        """
        Updates the status and notes of a test case execution.
        :param test_case_id: ID of the test case.
        :param run_id: ID of the test run.
        :param status: Execution status (e.g., 'passed', 'failed').
        :param notes: Notes to add to the execution.
        """
        # Step 1: Filter execution details
        payload_get_execution = {
            "jsonrpc": "2.0",
            "method": "TestExecution.filter",
            "params": {"query": {"run": run_id, "case": test_case_id}},
            "id": 1,
        }
        response = session.post(KIWI_URL, json=payload_get_execution)
        execution = response.json()
        if "error" in execution:
            raise Exception(f"Error retrieving execution: {execution['error']}")

        if not execution["result"]:
            raise Exception("No execution found for the specified test case and test run.")

        # Get the execution ID
        execution_id = execution["result"][0]["id"]

        # Step 2: Update execution status
        payload_update_execution = {
            "jsonrpc": "2.0",
            "method": "TestExecution.update",
            "params": {
                "execution_id": execution_id,
                "values": {
                    "status": STATUS_CODES[status],  # Dynamic mapping
                    "notes": notes,
                },
            },
            "id": 1,
        }
        response = session.post(KIWI_URL, json=payload_update_execution)
        result = response.json()
        if "error" in result:
            raise Exception(f"Error updating execution: {result['error']}")

        print(f"Test execution updated successfully for TestCase {test_case_id} with status: {status}")


@pytest.mark.tc_id(37)  # Replace 1 with dynamic test case IDs
def test_dynamic_addition():
    """
    Example test case: Checks addition functionality and updates status in Kiwi TCMS.
    """
    test_case_id = 37  # Replace with a dynamic ID from pytest marker or a config
    try:
        # Ensure login before running tests
        KiwiTCMS.login()

        # Perform the test logic
        result = 2 + 3
        assert result == 5, "Addition test failed!"

        # Update status to "passed"
        KiwiTCMS.update_test_execution(
            test_case_id=test_case_id,
            run_id=int(TEST_RUN_ID),
            status="passed",
            notes="Addition test passed successfully.",
        )
    except AssertionError as e:
        # Update status to "failed" on exception
        KiwiTCMS.update_test_execution(
            test_case_id=test_case_id,
            run_id=int(TEST_RUN_ID),
            status="failed",
            notes=f"Test failed: {str(e)}",
        )
        raise


# Dynamic Configurations
@pytest.fixture(scope="function")
def dynamic_test_case(request):
    """
    Dynamic fixture to pass test case IDs via pytest markers.
    Example: @pytest.mark.tc_id(123)
    """
    marker = request.node.get_closest_marker("tc_id")
    if not marker:
        raise ValueError("Missing 'tc_id' marker. Use @pytest.mark.tc_id(id).")
    return marker.args[0]
