import pytest
from kiwi_tcms_api import KiwiTCMSAPI

@pytest.fixture(scope="module")
def kiwi_setup():
    """Fixture to initialize KiwiTCMSAPI and create a test run."""
    kiwi = KiwiTCMSAPI()
    assert kiwi.check_connection(), "Failed to connect to Kiwi TCMS!"

    test_plan_id = 11  # Replace with valid Test Plan ID
    build_id = 1  # Replace with valid Build ID

    test_run_id = kiwi.create_test_run(test_plan_id, build_id)
    yield kiwi, test_run_id
