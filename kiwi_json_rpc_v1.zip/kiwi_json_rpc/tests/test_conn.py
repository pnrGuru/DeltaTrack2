from test_kiwi_dynamic_appr import KiwiTCMS


def test_connection_kiwi():
    KiwiTCMS.test_login()

def test_add_test_run():
    KiwiTCMS.