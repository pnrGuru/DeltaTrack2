import pytest
from kiwi_tcms_api import KiwiTCMSAPI

@pytest.fixture
def kiwi_tcms_api():
    # Create and return an instance of the KiwiTCMSAPI class
    kiwi = KiwiTCMSAPI()
    return kiwi

def test_connection(kiwi_tcms_api):
    # Test case to check the connection
    connection_status = kiwi_tcms_api.check_connection()
    assert connection_status is True, "Connection to Kiwi TCMS failed!"



# Check connection
def test_create_test_run(kiwi_tcms_api):
    summary = "Test Run for login functionality@@"
    plan_id = 10
    build_id = 10
    manager_id = 1
    environment = []

    # Create the test run
    test_run = kiwi_tcms_api.create_test_run(summary, plan_id, build_id, manager_id, environment)

    # Assert that the test run was created successfully
    assert test_run is not None, "Test run creation failed!"
    assert 'id' in test_run, "Test run ID is missing!"
    print(f"Test run created successfully: {test_run}")
