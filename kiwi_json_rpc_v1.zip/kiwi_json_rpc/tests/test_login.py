import pytest
from playwright.sync_api import sync_playwright
from kiwi_tcms_api import KiwiTCMSAPI
from pages.login_page import LoginPage

# Kiwi TCMS API setup
kiwi_api = KiwiTCMSAPI()


'''def test_login():
    # First, check the connection to Kiwi TCMS
    assert kiwi_api.check_connection() is True, "Connection to Kiwi TCMS failed!"
    '''


test_plan_id = 11  # ID of the test plan
build_id = 1  # ID of the build
manager_id = 1  # Your user ID as the manager
summary = "Test Run for login functionality"
environment = []  # You can add environment details here, for example: ["Staging", "Production"]


def test_login_functionality(kiwi_setup):
    kiwi, run_id = kiwi_setup
    assert run_id is not None, "Failed to create Test Run in Kiwi TCMS!"

    case_id = 26  # Replace with your test case ID

    try:
        # Simulate a passing test
        assert True
        status = 1  # Pass
    except AssertionError:
        status = 2  # Fail

    kiwi.update_test_case_result(run_id, case_id, status)


"""
    # Start Playwright test
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)  # Set headless=True if you don't want the browser to be visible
        page = browser.new_page()

        login_page = LoginPage(page)

        # Navigate to the login page and wait for it to load
        login_page.navigate_to_login('https://qa.app.ubq.network')

        # Wait for the username field, enter username, and proceed
        login_page.enter_username('sgadamsetty+padmin@deltatrak.com')  # Replace with actual username
        login_page.click_continue()

        # Wait for the password field, enter password, and submit
        login_page.enter_password('uM7p2H1n5c')  # Replace with actual password
        login_page.click_continue()

        # Wait and check if the dashboard is visible
        try:
            assert login_page.is_dashboard_visible(), "Dashboard is not visible after login"
            result = "pass"
        except AssertionError:
            result = "fail"

        # Update the test result in Kiwi TCMS
        update_result = kiwi_api.update_test_run_results(test_run_id, test_case_id, status=result)

        # Verify that the result update was successful
        assert update_result is not None, "Failed to update result in Kiwi TCMS"

        browser.close()
"""