import logging
from playwright.sync_api import Page, TimeoutError as PlaywrightTimeoutError

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


class PlaywrightDriver:
    def __init__(self, page: Page):
        """Initialize the Playwright driver with a page instance."""
        self.page = page

    def navigate_to(self, url: str):
        """Navigate to the given URL."""
        try:
            logging.info(f"Navigating to URL: {url}")
            self.page.goto(url, timeout=30000)  # 30 seconds timeout
            logging.info(f"Successfully navigated to URL: {url}")
        except PlaywrightTimeoutError as e:
            logging.error(f"Timeout while navigating to URL: {url}")
            raise Exception(f"Timeout while navigating to URL: {url}") from e

    def click_element(self, selector: str):
        """Click an element identified by the selector."""
        try:
            logging.info(f"Clicking element with selector: {selector}")
            self.page.wait_for_selector(selector, state="visible", timeout=15000)
            self.page.click(selector)
            logging.info(f"Successfully clicked element with selector: {selector}")
        except PlaywrightTimeoutError as e:
            logging.error(f"Timeout waiting for element to be clickable: {selector}")
            raise Exception(f"Timeout waiting for element to be clickable: {selector}") from e

    def fill_textbox(self, selector: str, text: str):
        """Fill a textbox identified by the selector with the given text."""
        try:
            logging.info(f"Filling textbox {selector} with text: {text}")
            self.page.wait_for_selector(selector, state="visible", timeout=15000)
            self.page.fill(selector, text)
            logging.info(f"Successfully filled textbox {selector} with text: {text}")
        except PlaywrightTimeoutError as e:
            logging.error(f"Timeout waiting for textbox: {selector}")
            raise Exception(f"Timeout waiting for textbox: {selector}") from e

    def is_element_visible(self, selector: str) -> bool:
        """Check if an element identified by the selector is visible."""
        try:
            logging.info(f"Checking visibility of element {selector}")
            self.page.wait_for_selector(selector, state="visible", timeout=15000)
            logging.info(f"Element {selector} is visible.")
            return True
        except PlaywrightTimeoutError:
            logging.error(f"Timeout waiting for element to be visible: {selector}")
            return False


