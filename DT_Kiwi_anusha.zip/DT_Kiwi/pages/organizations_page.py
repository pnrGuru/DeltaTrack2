from utils.playwright_driver import PlaywrightDriver


class NetworkAdminPage:
    def __init__(self, driver: PlaywrightDriver):
        self.driver = driver
        self.networkusers_icon = '//img[@src="/assets/images/icons/Setup-Icon.svg"]'
        self.org_header_txt = '//h2[contains(text(),"Organizations")]'
        self.org_add = '//img[@alt="add"]'
        self.add_enterprise_org = '//h5[contains(text(),"Enterprise Organization")]'
        self.input_enterprise_org = '//input[@id="add-org-name"]'
        self.input_description_org = '//input[@id="add-org-description"]'
        self.org_submit_btn = '//button[@id="add-org-submit-button"]'
        self.name_require_txt = '//p[contains(text(),"Name is required")]'
        self.description_require_txt = '//p[contains(text(),"Description is required")]'

    def verify_uielements(self) -> bool:
        """Checks Organization Lading page navigation successful."""
        return self.driver.is_element_visible(self.org_header_txt)
